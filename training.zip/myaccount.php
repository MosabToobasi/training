<?php
include "functions.php";
is_user_login();
include "header.php";
?>


My account Page


<?php
include "footer.php";
?>