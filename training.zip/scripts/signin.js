/**
 * Created by Mohamed on 1/28/2017.
 */
(function() {
    window.showSignInModal = function () {
        $("#signin-modal").modal("show");
    };
})();