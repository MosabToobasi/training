<?php

	function add_new_user($user_obj){
		/*TODO: write insert to db*/
		return 1;
	}


?>