<div class="njt-fb-mess-note-wrap">
    <h4><?php _e('What is Subscribe?', NJT_FB_MESS_I18N); ?></h4>
    <div class="njt-fb-mess-note">
        <?php _e('Subscribe your app to get updates for a page (A page may have up to 10 apps subscribing to it).', NJT_FB_MESS_I18N) ?>
    </div>
</div>