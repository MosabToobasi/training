<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" style="enable-background:new 0 0 100 100;" xml:space="preserve">
<style type="text/css">
    .st0{clip-path:url(#SVGID_2_);}
    .st1{fill:none;stroke:#87CDAE;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;}
    .st2{fill:none;stroke:#2279BF;stroke-width:2;stroke-miterlimit:10;}
    .st3{fill:#2279BF;}
    .st4{fill:#87CDAE;stroke:#2279BF;stroke-width:2;stroke-linejoin:round;stroke-miterlimit:10;}
    .st5{fill:#FFFFFF;stroke:#2279BF;stroke-width:2;stroke-linejoin:round;stroke-miterlimit:10;}
</style>
<g>
    <defs>
        <path id="SVGID_1_" d="M50,88.4L21.4,71.9c-0.4-0.2-0.7-0.7-0.7-1.2v-33c0-0.5,0.3-0.9,0.7-1.2L50,19.9c0.4-0.2,1-0.2,1.4,0
            L80,36.5c0.4,0.2,0.7,0.7,0.7,1.2v33c0,0.5-0.3,0.9-0.7,1.2L51.4,88.4C51,88.7,50.5,88.7,50,88.4z"/>
    </defs>
    <clipPath id="SVGID_2_">
        <use xlink:href="#SVGID_1_"  style="overflow:visible;"/>
    </clipPath>
    <g class="st0 back">
        <g class="motionblur">
            <line class="st1" x1="75" y1="36" x2="75.2" y2="47.6"/>
            <line class="st1" x1="69.3" y1="70.1" x2="69.5" y2="80.8"/>
            <line class="st1" x1="35.4" y1="67.8" x2="35.6" y2="80.2"/>
            <line class="st1" x1="45.4" y1="27.9" x2="45.7" y2="43.1"/>
            <line class="st1" x1="26.7" y1="38.7" x2="26.8" y2="43.1"/>
            <line class="st1" x1="58" y1="53.1" x2="58.2" y2="65.3"/>
        </g>
    </g>
</g>
<path class="st2" d="M50,88.4L21.4,71.9c-0.4-0.2-0.7-0.7-0.7-1.2v-33c0-0.5,0.3-0.9,0.7-1.2L50,19.9c0.4-0.2,1-0.2,1.4,0L80,36.5
    c0.4,0.2,0.7,0.7,0.7,1.2v33c0,0.5-0.3,0.9-0.7,1.2L51.4,88.4C51,88.7,50.5,88.7,50,88.4z"/>
<g>
    <path class="st3 rocket" d="M52.7,58c-1.6,0-6.7-0.7-6.7-0.7c0.6,1.7,2.5,7.1,2.5,7.1l0.9-3.2c1.5,4.8,3.3,11.5,3.3,11.5L56,61.2
        c0.5,1.5,1,3.2,1,3.2l1.7-7.1C58.8,57.3,54.3,58,52.7,58z"/>
</g>
<g class="rocket">
    <g>
        <path class="st4" d="M36.6,49.9l5.8-6l4.3,6.7l0,0c-3.3,0.9-5.3,3.3-5.1,5.9l0.2,2.4c0,0.2-0.2,0.3-0.4,0.3l-1.2,0
            c-0.5,0-1-0.3-1.1-0.6l-2.8-7.2C36,50.8,36.2,50.3,36.6,49.9z"/>
        <path class="st4" d="M68.2,50l-5.8-6l-4.3,6.7l0,0c3.2,0.9,5.3,3.3,5,5.9l-0.3,2.4c0,0.2,0.2,0.3,0.4,0.3l1.2,0
            c0.5,0,1-0.3,1.1-0.6l2.8-7.2C68.7,50.9,68.6,50.4,68.2,50z"/>
    </g>
    <path class="st4" d="M52.5,52.1l-0.2,0l-5.8,0l0.5,1.5c0.3,0.8,1,1.3,1.8,1.3l3.4,0l0.2,0l3.4,0c0.8,0,1.5-0.5,1.8-1.3l0.5-1.5
        L52.5,52.1z"/>
    <path class="st4" d="M52.5,47.5l-0.2,0l-9.6,0c0.7,1.7,1.4,3,1.8,3.8c0.3,0.5,0.9,0.9,1.4,0.9l0.6,0l5.8,0l0.2,0l5.8,0l0.6,0
        c0.6,0,1.1-0.3,1.4-0.9c0.4-0.8,1.1-2,1.8-3.8L52.5,47.5z"/>
    <path class="st5" d="M59.4,18.3l-6.8,0l-0.2,0l-6.8,0c-8.8,13.9-5.6,21.4-2.9,29.2l9.6,0l0.2,0l9.7,0
        C64.9,39.6,68.2,32.3,59.4,18.3z"/>
    <path class="st4" d="M52.6,10.2L52.6,10.2l-0.2,0c-2.8,2.6-5.1,5.3-6.9,8.1l6.8,0l0.2,0l6.8,0C57.6,15.5,55.3,12.8,52.6,10.2z"/>
    <ellipse transform="matrix(2.703083e-03 -1 1 2.703083e-03 21.2413 83.3837)" class="st4" cx="52.4" cy="31" rx="6.1" ry="6.1"/>
</g>
</svg>